<?php

return array(
  'status_title' => 'Статус посилки:',
  'not_found' => 'Не знайдено',
  'parcel_num' => 'Введіть номер посилки',
  'track_parcel' => 'Відстежити посилку',
);