<?php

return array(
  'big_title' => 'Міжнародна кур\'єрська служба',
  'small_title' => 'Посилки з/в Ізраїль',
);