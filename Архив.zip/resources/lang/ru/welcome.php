<?php

return array(
  'big_title' => 'Международная курьерская служба',
  'small_title' => 'Посылки из/в Израиль',
);