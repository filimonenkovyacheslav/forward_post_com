<?php

return array(
  'status_title' => 'Статус посылки:',
  'not_found' => 'Не найдено',
  'parcel_num' => 'Введите номер посылки',
  'track_parcel' => 'Отследить посылку',
);