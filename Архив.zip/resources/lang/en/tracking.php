<?php

return array(
  'status_title' => 'Parcel status:',
  'not_found' => 'Not found',
  'parcel_num' => 'Enter the parcel number',
  'track_parcel' => 'To track the parcel',
);