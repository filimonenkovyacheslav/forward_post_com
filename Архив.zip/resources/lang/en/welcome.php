<?php

return array(
  'big_title' => 'International courier service',
  'small_title' => 'Parcels from/to Israel',
);