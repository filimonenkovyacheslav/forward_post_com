<?php

return array(
  'big_title' => 'שירות שליחויות בינלאומי',
  'small_title' => 'חבילות מ / לישראל',
);