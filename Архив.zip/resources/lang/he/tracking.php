<?php

return array(
  'status_title' => 'מצב חבילה',
  'not_found' => 'לא נמצא',
  'parcel_num' => 'הכניסו את מספר המעקב שלכם כאן',
  'track_parcel' => 'מעקב',
);